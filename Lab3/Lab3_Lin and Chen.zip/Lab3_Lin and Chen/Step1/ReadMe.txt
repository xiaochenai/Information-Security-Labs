compile:
javac convert.java
run:
java convert