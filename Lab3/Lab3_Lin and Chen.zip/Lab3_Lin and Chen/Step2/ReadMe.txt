compile:
javac hash.java
run:
java hash