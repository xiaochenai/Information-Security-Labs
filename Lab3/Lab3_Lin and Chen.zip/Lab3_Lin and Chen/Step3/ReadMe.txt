part1:
this part use RSA encryption to generate signature
part2:
this part use the method of signature object to generate signature

put the hash.txt and private key in each folder

