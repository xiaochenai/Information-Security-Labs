part1:
corresponding to part1 in Step3
part2:
corresponding to part2 in Step3

put hash.txt public key in each folder
in part1 put in sig_En.txt
in part2 put in sig.txt