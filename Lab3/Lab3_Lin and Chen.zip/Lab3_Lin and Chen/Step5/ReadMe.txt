compile:
javac grand.java
run:
java grand