compile:
javac wrap.java
run:
java wrap

put RAND.txt and public key in folder