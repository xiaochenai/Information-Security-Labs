compile:
javac unwrap.java
run:
java unwrap

put En-Ran.txt and private key in folder