put public key in Client

put private key in Server

Client:
compile
javac client.java
run
java client

Server:
complie
javac MultiUserServer.java
run
java MultiUserServer

the port number is 8888