In the files folder is the txt file generated in android.

the android implement is based on the spongycastle.
