compile:
javac multiUserServer.java
run:
java ultiUserServer

this step is same with step3.
and the plaintext can not be too large