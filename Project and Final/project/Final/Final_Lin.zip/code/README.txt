ECDH_DH_compare.java is for step 5
ECDSA_RSADSA.java is for step 4

others are used in step4 and step 5