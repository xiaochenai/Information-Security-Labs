compile  javac GCM_DECRYPT.java

run java GCM_DECRYPT