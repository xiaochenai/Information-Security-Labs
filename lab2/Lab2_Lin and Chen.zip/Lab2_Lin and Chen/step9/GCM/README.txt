compile: javac GCM_ENCRYPT.java

run: java GCM_ENCRYPT

copy the key.dat IV.hex and encrypted file to step10-GCM folder for step 10