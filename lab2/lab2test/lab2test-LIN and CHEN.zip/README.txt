compile: 
javac test1.java
javac test2.java
javac test4.java

run:
java test1
java test2
java test4

output:
average time.txt for test2.java
average_2.txt for test4.java

the process to draw figure in matlab have be shown in the end of report